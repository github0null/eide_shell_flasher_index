
## Build

The scripts used to build this distribution are in:

- `distro-info/scripts`

For the prerequisites and more details on the build procedure and source code, please contact the following e-mail address: support@mounriver.com 


## Documentation

The original documentation is available in the `share/doc` folder.


###
安装驱动时需要获取sudo权限.如未成功安装,请手动执行 "sudo ./tools/wch_openocd/beforeinstall/start.sh".
