#!/bin/sh
ProjName="w800"

mv ./Obj/"$ProjName".elf ./"$ProjName".elf
mv ./Lst/"$ProjName".map ./"$ProjName".map